// ==========================================
// 1. EXTRACT NATIVE PLUGINS FROM CAPACITOR
// ==========================================
const { CapacitorSQLite, GoogleAuth, Device, Preferences, Haptics, Filesystem } = window.Capacitor.Plugins;

// ==========================================
// 2. STATE & GLOBALS
// ==========================================
let currentSession = null;
let myDevice = { deviceId: null, deviceName: null };
let loadedData = { company: {}, clients: [], services: [] };
let invoiceItemsTemp = [];
let currentClientDashboardId = null;
let currentPreviewContext = {};
let currentZoom = 1;
let syncTimeout = null;

const SYNC_DELAY = 5000;
const CURRENT_COMPANY_ID = 'COMP-1';

// ==========================================
// 3. PURE NATIVE SQLITE WRAPPERS
// ==========================================
async function dbRun(statement, values = []) {
    return await CapacitorSQLite.run({ database: "invoicepro_db", statement: statement, values: values });
}
async function dbQuery(statement, values = []) {
    return await CapacitorSQLite.query({ database: "invoicepro_db", statement: statement, values: values });
}
async function dbExecute(statements) {
    return await CapacitorSQLite.execute({ database: "invoicepro_db", statements: statements });
}

// ==========================================
// 4. BOOT SEQUENCE
// ==========================================
window.onload = async () => {
    try {
        if (window.Capacitor.Plugins.StatusBar) {
            window.Capacitor.Plugins.StatusBar.setStyle({ style: 'LIGHT' });
        }
    } catch (e) { }

    try {
        await GoogleAuth.initialize({
            clientId: '396451417970-aqdjn20qgc2hktuna7ejo4rc87cg3uci.apps.googleusercontent.com', // REPLACE THIS
            scopes: ['https://www.googleapis.com/auth/drive.appdata'],
            grantOfflineAccess: true,
        });
    } catch (e) { console.warn("Google Auth init warning", e); }
    await initSQLite();
    document.getElementById('loaderOverlay').classList.add('d-none');
    window.showView("dashboardView");
    await refreshLocalCache()
    /*
        const savedSession = localStorage.getItem('InvoiceProSession');
        if (savedSession) {
            currentSession = JSON.parse(savedSession);
            await initSQLite();
            await verifyLockAndLoad();
        } else {
            document.getElementById('loaderOverlay').classList.add('d-none');
            window.showView('loginView');
        }
            */
};

async function initSQLite() {
    try {
        await CapacitorSQLite.createConnection({ database: "invoicepro_db", encrypted: false, mode: "no-encryption", version: 1, readonly: false });
        await CapacitorSQLite.open({ database: "invoicepro_db" });

        const schema = `
            CREATE TABLE IF NOT EXISTS CompanyMaster (id TEXT PRIMARY KEY, name TEXT, add_txt TEXT, mob TEXT, email TEXT, logo TEXT, upi TEXT, upiName TEXT);
            CREATE TABLE IF NOT EXISTS clientMaster (id TEXT PRIMARY KEY, cid TEXT, name TEXT, companyName TEXT, mob TEXT, mcode TEXT DEFAULT '91', email TEXT, dob TEXT, isDeleted INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS serviceMaster (id TEXT PRIMARY KEY, cid TEXT, name TEXT, desc TEXT, rt REAL, isDeleted INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS invoiceMaster (id TEXT PRIMARY KEY, cid TEXT, clid TEXT, date TEXT, ddate TEXT, inum TEXT, gamt REAL, damt REAL, rof REAL, namt REAL, ispaid INTEGER DEFAULT 0, isDeleted INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS invoiceitems (id TEXT PRIMARY KEY, cid TEXT, clid TEXT, iid TEXT, name TEXT, desc TEXT, rt REAL, qty REAL, amt REAL);
            CREATE TABLE IF NOT EXISTS receiptMaster (id TEXT PRIMARY KEY, cid TEXT, clid TEXT, invid TEXT, date TEXT, rnum TEXT, amt REAL, mode TEXT, note TEXT, isDeleted INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS receiptInvoiceAllocationMaster (id TEXT PRIMARY KEY, rid TEXT, iid TEXT, amt REAL);
        `;
        await dbExecute(schema);
    } catch (err) {
        console.error("SQLite Init Error:", err);
        alert("Failed to initialize local database.");
    }
}

async function refreshLocalCache() {
    if (!currentSession) return;
    try {
        const [clients, services, company] = await Promise.all([
            dbQuery(`SELECT * FROM clientMaster WHERE isDeleted = 0`),
            dbQuery(`SELECT * FROM serviceMaster WHERE isDeleted = 0`),
            dbQuery(`SELECT * FROM CompanyMaster WHERE id = ?`, [CURRENT_COMPANY_ID])
        ]);

        loadedData.clients = clients.values || [];
        loadedData.services = services.values || [];
        loadedData.company = company.values?.[0] || {};

        for (let c of loadedData.clients) {
            let invRes = await dbQuery(`SELECT SUM(namt) as tInv FROM invoiceMaster WHERE clid = ? AND isDeleted = 0`, [c.id]);
            let recRes = await dbQuery(`SELECT SUM(amt) as tRec FROM receiptMaster WHERE clid = ? AND isDeleted = 0`, [c.id]);
            let allocRes = await dbQuery(`SELECT SUM(amt) as tAll FROM receiptInvoiceAllocationMaster WHERE rid IN (SELECT id FROM receiptMaster WHERE clid = ? AND isDeleted = 0)`, [c.id]);

            let tInv = invRes.values[0]?.tInv || 0;
            let tRec = recRes.values[0]?.tRec || 0;
            let tAll = allocRes.values[0]?.tAll || 0;

            c.balanceDue = tInv - (tRec - tAll);
        }
        await window.renderTables();
    } catch (e) { console.error("Cache refresh error:", e); }
}

// ==========================================
// 5. AUTH & DRIVE SYNC (Fixed URLs)
// ==========================================
async function getDeviceInfo() {
    let { value: deviceId } = await Preferences.get({ key: 'InvoicePro_DeviceID' });
    if (!deviceId) {
        deviceId = window.generateUID('DEV');
        await Preferences.set({ key: 'InvoicePro_DeviceID', value: deviceId });
    }
    let deviceName = (await Device.getInfo()).model || 'Unknown Android';
    myDevice = { deviceId, deviceName };
    return myDevice;
}

window.handleLogin = async function () {
    document.getElementById('loaderOverlay').classList.remove('d-none');
    document.getElementById('loaderText').innerText = "Authenticating...";
    document.getElementById('loaderOverlay').classList.add('d-none');
    window.showView("dashboardView")
    /*
    try {
        const googleUser = await GoogleAuth.signIn();
        currentSession = { token: googleUser.authentication.accessToken, user: googleUser.email };
        await initSQLite();
        await verifyLockAndLoad(true);
    } catch (e) {
        alert("Google Sign-In failed.");
        document.getElementById('loaderOverlay').classList.add('d-none');
    }*/
};

async function verifyLockAndLoad(isManualLogin = false) {
    document.getElementById('loaderText').innerText = "Verifying Device Lock...";
    const device = await getDeviceInfo();

    try {
        // FIX: Properly encoded, single quotes, separate spaces parameter
        const query = encodeURIComponent("name='device_lock.json'");
        const url = `https://www.googleapis.com/drive/v3/files?q=${query}&spaces=appDataFolder&fields=files(id)`;

        const response = await fetch(url, { headers: { 'Authorization': 'Bearer ' + currentSession.token } });
        const result = await response.json();

        if (result.files && result.files.length > 0) {
            const fileRes = await fetch(`https://www.googleapis.com/drive/v3/files/${result.files[0].id}?alt=media`, { headers: { 'Authorization': 'Bearer ' + currentSession.token } });
            const activeLock = await fileRes.json();

            if (activeLock.deviceId !== device.deviceId) {
                document.getElementById('loaderOverlay').classList.add('d-none');
                const force = confirm(`ACCESS BLOCKED\nLocked to: ${activeLock.deviceName}\nLast synced: ${new Date(activeLock.timestamp).toLocaleString()}\n\nForce login and take over sync duties?`);
                if (force) {
                    document.getElementById('loaderOverlay').classList.remove('d-none');
                    document.getElementById('loaderText').innerText = "Forcing Takeover...";
                    await executeLoadAndSync(device);
                } else {
                    window.logout();
                }
                return;
            }
        }
        await executeLoadAndSync(device);
    } catch (e) {
        if (isManualLogin) alert("Network error during login.");
        document.getElementById('loaderOverlay').classList.add('d-none');
    }
}

async function executeLoadAndSync(device) {
    await takeOverLock(device);
    localStorage.setItem('InvoiceProSession', JSON.stringify(currentSession));
    document.getElementById('loaderText').innerText = "Syncing Ledger...";
    await pullFromGoogleDrive();
}

async function takeOverLock(device) {
    const lockData = { deviceId: device.deviceId, deviceName: device.deviceName, timestamp: new Date().toISOString() };
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify({ name: 'device_lock.json', parents: ['appDataFolder'] })], { type: 'application/json' }));
    form.append('file', new Blob([JSON.stringify(lockData)], { type: 'application/json' }));
    await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', { method: 'POST', headers: { 'Authorization': 'Bearer ' + currentSession.token }, body: form });
}

/*window.triggerDriveSync = function () {
    window.updateSyncStatus('Pending');
    if (syncTimeout) clearTimeout(syncTimeout);
    syncTimeout = setTimeout(backupToGoogleDrive, SYNC_DELAY);
}*/

async function backupToGoogleDrive() {
    if (!navigator.onLine || !currentSession) return;
    window.updateSyncStatus('Syncing...');
    try {
        const [invoices, invoiceItems, receipts, allocations] = await Promise.all([
            dbQuery(`SELECT * FROM invoiceMaster`),
            dbQuery(`SELECT * FROM invoiceitems`),
            dbQuery(`SELECT * FROM receiptMaster`),
            dbQuery(`SELECT * FROM receiptInvoiceAllocationMaster`)
        ]);

        const fullBackup = {
            company: loadedData.company,
            clients: loadedData.clients,
            services: loadedData.services,
            invoices: invoices.values || [],
            invoiceItems: invoiceItems.values || [],
            receipts: receipts.values || [],
            allocations: allocations.values || []
        };

        const form = new FormData();
        form.append('metadata', new Blob([JSON.stringify({ name: 'invoicepro_backup.json', parents: ['appDataFolder'] })], { type: 'application/json' }));
        form.append('file', new Blob([JSON.stringify(fullBackup)], { type: 'application/json' }));

        await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', { method: 'POST', headers: { 'Authorization': 'Bearer ' + currentSession.token }, body: form });
        await takeOverLock(myDevice);
        window.updateSyncStatus('Synced');
    } catch (e) { window.updateSyncStatus('Offline'); }
}

async function pullFromGoogleDrive() {
    try {
        // FIX: Properly encoded, single quotes, separate spaces parameter
        const query = encodeURIComponent("name='invoicepro_backup.json'");
        const url = `https://www.googleapis.com/drive/v3/files?q=${query}&spaces=appDataFolder&fields=files(id)`;

        const response = await fetch(url, { headers: { 'Authorization': 'Bearer ' + currentSession.token } });
        const result = await response.json();

        if (result.files && result.files.length > 0) {
            const fileRes = await fetch(`https://www.googleapis.com/drive/v3/files/${result.files[0].id}?alt=media`, { headers: { 'Authorization': 'Bearer ' + currentSession.token } });
            const driveData = await fileRes.json();

            await dbExecute(`DELETE FROM CompanyMaster; DELETE FROM clientMaster; DELETE FROM serviceMaster; DELETE FROM invoiceMaster; DELETE FROM invoiceitems; DELETE FROM receiptMaster; DELETE FROM receiptInvoiceAllocationMaster;`);

            if (driveData.company && driveData.company.id) await dbRun(`INSERT INTO CompanyMaster (id, name, add_txt, mob, email, logo, upi, upiName) VALUES (?,?,?,?,?,?,?,?)`, [driveData.company.id, driveData.company.name, driveData.company.add_txt, driveData.company.mob, driveData.company.email, driveData.company.logo, driveData.company.upi, driveData.company.upiName]);
            else await dbRun(`INSERT OR IGNORE INTO CompanyMaster (id, name) VALUES (?, ?)`, [CURRENT_COMPANY_ID, 'My Company']);

            if (driveData.clients) for (let c of driveData.clients) await dbRun(`INSERT INTO clientMaster (id, cid, name, companyName, mob, mcode, email, dob, isDeleted) VALUES (?,?,?,?,?,?,?,?,?)`, [c.id, c.cid, c.name, c.companyName, c.mob, c.mcode, c.email, c.dob, c.isDeleted]);
            if (driveData.services) for (let s of driveData.services) await dbRun(`INSERT INTO serviceMaster (id, cid, name, desc, rt, isDeleted) VALUES (?,?,?,?,?,?)`, [s.id, s.cid, s.name, s.desc, s.rt, s.isDeleted]);
            if (driveData.invoices) for (let i of driveData.invoices) await dbRun(`INSERT INTO invoiceMaster (id, cid, clid, date, ddate, inum, gamt, damt, rof, namt, ispaid, isDeleted) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [i.id, i.cid, i.clid, i.date, i.ddate, i.inum, i.gamt, i.damt, i.rof, i.namt, i.ispaid, i.isDeleted]);
            if (driveData.invoiceItems) for (let ii of driveData.invoiceItems) await dbRun(`INSERT INTO invoiceitems (id, cid, clid, iid, name, desc, rt, qty, amt) VALUES (?,?,?,?,?,?,?,?,?)`, [ii.id, ii.cid, ii.clid, ii.iid, ii.name, ii.desc, ii.rt, ii.qty, ii.amt]);
            if (driveData.receipts) for (let r of driveData.receipts) await dbRun(`INSERT INTO receiptMaster (id, cid, clid, invid, date, rnum, amt, mode, note, isDeleted) VALUES (?,?,?,?,?,?,?,?,?,?)`, [r.id, r.cid, r.clid, r.invid, r.date, r.rnum, r.amt, r.mode, r.note, r.isDeleted]);
            if (driveData.allocations) for (let a of driveData.allocations) await dbRun(`INSERT INTO receiptInvoiceAllocationMaster (id, rid, iid, amt) VALUES (?,?,?,?)`, [a.id, a.rid, a.iid, a.amt]);

            await refreshLocalCache();
            window.showView('dashboardView');
            document.getElementById('loaderOverlay').classList.add('d-none');
        } else {
            await refreshLocalCache();
            window.showView('companySetupView');
            document.getElementById('loaderOverlay').classList.add('d-none');
        }
    } catch (e) {
        console.error("Pull from Drive error:", e);
        await refreshLocalCache();
        window.showView('dashboardView');
        document.getElementById('loaderOverlay').classList.add('d-none');
    }
}

window.logout = function () {
    currentSession = null;
    localStorage.removeItem('InvoiceProSession');
    document.getElementById('loaderOverlay').classList.add('d-none');
    window.showView('loginView');
}

// ==========================================
// 6. OTA CHECK LISTENER (Sidebar Button)
// ==========================================
window.checkForOtaUpdate = function () {
    // Navigating back to localhost triggers the APK's root bootloader index.html to run again
    window.location.replace("http://localhost");
}

// ==========================================
// 7. CORE BUSINESS LOGIC & UTILS
// ==========================================
window.lastMainView = 'dashboardView';
window.generateUID = (prefix) => prefix + '-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase();

window.updateInvoicePaidStatus = async function (invoiceId) {
    let allocs = await dbQuery(`SELECT SUM(amt) as total FROM receiptInvoiceAllocationMaster WHERE iid = ?`, [invoiceId]);
    let inv = await dbQuery(`SELECT namt FROM invoiceMaster WHERE id = ?`, [invoiceId]);
    if (inv.values?.length > 0) {
        let isPaid = (allocs.values[0]?.total || 0) >= inv.values[0].namt ? 1 : 0;
        await dbRun(`UPDATE invoiceMaster SET ispaid = ? WHERE id = ?`, [isPaid, invoiceId]);
    }
}

window.sendWhatsAppReminder = async function (invId) {
    const invRes = await dbQuery(`SELECT inum, namt, (namt - COALESCE((SELECT SUM(amt) FROM receiptInvoiceAllocationMaster WHERE iid = invoiceMaster.id), 0)) as balance, clid FROM invoiceMaster WHERE id = ?`, [invId]);
    const inv = invRes.values[0];
    const cli = loadedData.clients.find(c => c.id === inv.clid);
    if (!cli || !cli.mob) return alert("No mobile number saved for this client.");

    let text = `Hello ${cli.name},\n\nA gentle reminder that Invoice *${inv.inum}* has a pending balance of *₹${inv.balance.toFixed(2)}*.\n`;
    if (loadedData.company.upi) {
        text += `\nYou can pay directly via UPI using this link:\nupi://pay?pa=${loadedData.company.upi}&pn=${encodeURIComponent(loadedData.company.upiName || '')}&tn=Invoice+${inv.inum}&am=${inv.balance.toFixed(2)}&cu=INR\n`;
    }
    text += `\nPlease let us know when this can be cleared. Thank you!`;
    window.open(`https://wa.me/91${cli.mob}?text=${encodeURIComponent(text)}`, '_blank');
}

window.handleLogoUpload = function (event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) { document.getElementById('setup_comp_logo_base64').value = e.target.result; };
    reader.readAsDataURL(file);
};

window.saveInitialCompany = async function () {
    const name = document.getElementById('setup_comp_name').value.trim();
    if (!name) return alert("Company Name is required!");

    await dbRun(
        `INSERT OR REPLACE INTO CompanyMaster (id, name, add_txt, mob, email, logo, upi, upiName) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [CURRENT_COMPANY_ID, name, document.getElementById('setup_comp_add').value, document.getElementById('setup_comp_mob').value.replace(/[^\d]/g, ''), document.getElementById('setup_comp_email').value, document.getElementById('setup_comp_logo_base64').value, document.getElementById('setup_comp_upi').value, document.getElementById('setup_comp_upiname').value]
    );

    window.vibrate('success');
    await refreshLocalCache();
    window.triggerDriveSync();
    window.showView('dashboardView');
};

// ==== UI UTILS ====
window.showView = function (viewId) {
    if (['dashboardView', 'clientDashboardView'].includes(viewId)) window.lastMainView = viewId;
    document.querySelectorAll('.app-view').forEach(v => v.classList.add('d-none'));
    document.getElementById(viewId).classList.remove('d-none');
}

window.switchTab = function (tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('d-none'));
    document.getElementById('tab-' + tabId).classList.remove('d-none');

    document.querySelectorAll('#mainSegment .nav-link').forEach(link => {
        if (link.getAttribute('onclick').includes(tabId)) link.classList.add('active');
        else link.classList.remove('active');
    });
}

window.updateSyncStatus = function (status) {
    const b = document.getElementById('syncBadge');
    if (b) {
        b.innerText = status;
        b.className = 'badge ' + (status === 'Synced' ? 'bg-success' : status === 'Pending' ? 'bg-danger' : 'bg-warning text-dark');
    }
}

window.vibrate = async function (type = 'light') {
    if (Haptics) {
        if (type === 'success') await Haptics.impact({ style: 'MEDIUM' });
        else if (type === 'error') await Haptics.vibrate({ duration: 300 });
        else await Haptics.impact({ style: 'LIGHT' });
    }
}

// ==========================================
// 8. CRUD OPERATIONS
// ==========================================
window.saveClient = async function () {
    const id = document.getElementById('c_id').value || window.generateUID('CLI');
    const name = document.getElementById('c_name').value.trim().toUpperCase();
    if (!name) return alert("Client name required!");

    await dbRun(`INSERT OR REPLACE INTO clientMaster (id, cid, name, companyName, mob, mcode, email, dob, isDeleted) VALUES (?,?,?,?,?,?,?,?,0)`,
        [id, CURRENT_COMPANY_ID, name, document.getElementById('c_company').value, document.getElementById('c_mobile').value.replace(/[^\d]/g, ''), '91', document.getElementById('c_email').value, document.getElementById('c_dob').value]);

    window.vibrate('success'); await refreshLocalCache(); window.triggerDriveSync(); window.showView(window.lastMainView);
}

window.saveService = async function () {
    const id = document.getElementById('s_id').value || window.generateUID('SRV');
    const name = document.getElementById('s_name').value.trim().toUpperCase();
    const rate = parseFloat(document.getElementById('s_rate').value) || 0;
    if (!name || !rate) return alert("Name and Rate required!");

    await dbRun(`INSERT OR REPLACE INTO serviceMaster (id, cid, name, desc, rt, isDeleted) VALUES (?,?,?,?,?,0)`, [id, CURRENT_COMPANY_ID, name, document.getElementById('s_desc').value, rate]);
    window.vibrate('success'); await refreshLocalCache(); window.triggerDriveSync(); window.showView(window.lastMainView);
}

window.addItem = function () {
    const sName = document.getElementById('item_service').value.trim();
    const s = loadedData.services.find(x => x.name === sName);
    if (!s) return alert("Select a valid service!");
    const qty = parseFloat(document.getElementById('item_qty').value);
    const rt = parseFloat(document.getElementById('item_rate').value);
    if (!qty || !rt) return;

    invoiceItemsTemp.push({ name: s.name, desc: document.getElementById('item_desc').value, rt: rt, qty: qty, amt: qty * rt });
    ['item_service', 'item_desc', 'item_rate'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('item_qty').value = '1';
    window.renderItems();
}

window.renderItems = function () {
    let list = document.getElementById('itemList');
    list.innerHTML = '';
    let total = 0;
    invoiceItemsTemp.forEach((i, idx) => {
        list.innerHTML += `<div class="list-group-item d-flex justify-content-between align-items-center" onclick="openEditItemModal(${idx})">
            <div><h6 class="mb-0">${i.name}</h6><small class="text-muted">${i.desc}</small></div>
            <div class="text-end me-3"><small>${i.qty} x ${i.rt}</small><br><b>${i.amt.toFixed(2)}</b></div>
            <button class="btn btn-sm btn-outline-danger" onclick="event.stopPropagation(); removeItem(${idx})"><i class="bi bi-trash"></i></button>
        </div>`;
        total += i.amt;
    });
    document.getElementById('inv_total').value = total.toFixed(2);
    window.calculateNet();
}
window.removeItem = function (index) { invoiceItemsTemp.splice(index, 1); window.renderItems(); }
window.calculateNet = function () { document.getElementById('inv_net').value = ((parseFloat(document.getElementById('inv_total').value) || 0) - (parseFloat(document.getElementById('inv_disc').value) || 0) + (parseFloat(document.getElementById('inv_round').value) || 0)).toFixed(2); }
window.autoSetDueDate = function () { let d = document.getElementById('inv_date').value; if (d) { let t = new Date(d); t.setDate(t.getDate() + 15); document.getElementById('inv_due_date').value = t.toISOString().split('T')[0]; } }

window.saveInvoice = async function () {
    const id = document.getElementById('inv_id').value || window.generateUID('INV');
    const client = loadedData.clients.find(c => c.name === document.getElementById('inv_client').value.trim());
    if (!client) return alert("Valid client required!");
    if (invoiceItemsTemp.length === 0) return alert("Add items!");

    await dbRun(`INSERT OR REPLACE INTO invoiceMaster (id, cid, clid, date, ddate, inum, gamt, damt, rof, namt, ispaid, isDeleted) VALUES (?,?,?,?,?,?,?,?,?,?,?,0)`,
        [id, CURRENT_COMPANY_ID, client.id, document.getElementById('inv_date').value, document.getElementById('inv_due_date').value, document.getElementById('inv_num').value, parseFloat(document.getElementById('inv_total').value) || 0, parseFloat(document.getElementById('inv_disc').value) || 0, parseFloat(document.getElementById('inv_round').value) || 0, parseFloat(document.getElementById('inv_net').value) || 0, 0]);

    await dbRun(`DELETE FROM invoiceitems WHERE iid = ?`, [id]);
    for (let item of invoiceItemsTemp) await dbRun(`INSERT INTO invoiceitems (id, cid, clid, iid, name, desc, rt, qty, amt) VALUES (?,?,?,?,?,?,?,?,?)`, [window.generateUID('ITM'), CURRENT_COMPANY_ID, client.id, id, item.name, item.desc, item.rt, item.qty, item.amt]);

    let initAmt = parseFloat(document.getElementById('inv_rec_amount').value) || 0;
    if (initAmt > 0) await processReceiptCore(client.id, id, document.getElementById('inv_date').value, initAmt, document.getElementById('inv_rec_mode').value, 'Initial Payment');

    window.vibrate('success'); await refreshLocalCache(); window.triggerDriveSync(); window.showView(window.lastMainView);
}

// Receipts & Dynamic SQL FIFO
async function processReceiptCore(clientId, specificInvoiceId, date, amount, mode, note) {
    const rid = window.generateUID('RCT');
    await dbRun(`INSERT INTO receiptMaster (id, cid, clid, invid, date, rnum, amt, mode, note, isDeleted) VALUES (?,?,?,?,?,?,?,?,?,0)`, [rid, CURRENT_COMPANY_ID, clientId, specificInvoiceId || '', date, "REC-" + Date.now().toString().slice(-6), amount, mode, note]);

    let amtLeft = parseFloat(amount);
    if (specificInvoiceId) {
        await dbRun(`INSERT INTO receiptInvoiceAllocationMaster (id, rid, iid, amt) VALUES (?,?,?,?)`, [window.generateUID('ALC'), rid, specificInvoiceId, amtLeft]);
        await window.updateInvoicePaidStatus(specificInvoiceId);
        return rid;
    }

    const unpaidRes = await dbQuery(`SELECT id, (namt - COALESCE((SELECT SUM(amt) FROM receiptInvoiceAllocationMaster WHERE iid = invoiceMaster.id), 0)) as balance FROM invoiceMaster WHERE clid = ? AND ispaid = 0 AND isDeleted = 0 ORDER BY date ASC`, [clientId]);

    for (let inv of (unpaidRes.values || [])) {
        if (amtLeft <= 0) break;
        if (inv.balance > 0) {
            let alloc = Math.min(amtLeft, inv.balance);
            await dbRun(`INSERT INTO receiptInvoiceAllocationMaster (id, rid, iid, amt) VALUES (?,?,?,?)`, [window.generateUID('ALC'), rid, inv.id, alloc]);
            amtLeft -= alloc;
            await window.updateInvoicePaidStatus(inv.id);
        }
    }
}

window.saveReceipt = async function () {
    const cId = document.getElementById('rec_client_id').value;
    const amt = parseFloat(document.getElementById('rec_amount').value) || 0;
    if (!cId || amt <= 0) return alert("Client and Amount required!");

    await processReceiptCore(cId, document.getElementById('rec_invoice').value, document.getElementById('rec_date').value, amt, document.getElementById('rec_mode').value, document.getElementById('rec_notes').value);

    window.vibrate('success');
    const client = loadedData.clients.find(c => c.id === cId);
    if (client && client.mob && client.mob.length >= 10) {
        if (confirm('Receipt Saved. Send confirmation via WhatsApp?')) {
            let waText = `Hello ${client.name},\n\nWe have received your payment of *₹${amt.toFixed(2)}*.\nPayment Mode: ${document.getElementById('rec_mode').value}\n\nThank you for your business!`;
            window.open(`https://wa.me/91${client.mob}?text=${encodeURIComponent(waText)}`, '_blank');
        }
    }

    await refreshLocalCache(); window.triggerDriveSync(); window.showView(window.lastMainView);
}

window.saveQuickSale = async function () {
    const amt = parseFloat(document.getElementById('qs_amount').value);
    if (!amt || amt <= 0) return alert("Valid amount required!");
    let walkIn = loadedData.clients.find(c => c.id === 'SYS-WALKIN');
    if (!walkIn) {
        walkIn = { id: 'SYS-WALKIN', name: 'Walk-In Customer' };
        await dbRun(`INSERT INTO clientMaster (id, cid, name, mcode, isDeleted) VALUES (?,?,?,?,0)`, [walkIn.id, CURRENT_COMPANY_ID, walkIn.name, '91']);
    }
    await processReceiptCore(walkIn.id, '', new Date().toISOString().split('T')[0], amt, document.getElementById('qs_mode').value, document.getElementById('qs_notes').value);

    bootstrap.Modal.getInstance(document.getElementById('quickSaleModal')).hide();
    window.vibrate('success'); await refreshLocalCache(); window.triggerDriveSync();
}

window.confirmDelete = async function (type, id) {
    let warning = `Delete this ${type}?`;
    if (type === 'invoice') {
        const allocs = await dbQuery(`SELECT rid FROM receiptInvoiceAllocationMaster WHERE iid = ?`, [id]);
        if (allocs.values?.length > 0) warning = `WARNING: Linked receipts found!\nDeleting invoice deletes linked receipts (Rule 1) & items (Rule 2). Proceed?`;
    }
    if (confirm(warning)) executeDelete(type, id);
}

async function executeDelete(type, id) {
    if (type === 'invoice') {
        const allocs = await dbQuery(`SELECT rid FROM receiptInvoiceAllocationMaster WHERE iid = ?`, [id]);
        for (let a of (allocs.values || [])) await dbRun(`UPDATE receiptMaster SET isDeleted = 1 WHERE id = ?`, [a.rid]);
        await dbRun(`DELETE FROM receiptInvoiceAllocationMaster WHERE iid = ?`, [id]);
        await dbRun(`DELETE FROM invoiceitems WHERE iid = ?`, [id]);
        await dbRun(`UPDATE invoiceMaster SET isDeleted = 1 WHERE id = ?`, [id]);
    } else if (type === 'client') await dbRun(`UPDATE clientMaster SET isDeleted = 1 WHERE id = ?`, [id]);
    else if (type === 'service') await dbRun(`UPDATE serviceMaster SET isDeleted = 1 WHERE id = ?`, [id]);
    else if (type === 'receipt') {
        await dbRun(`UPDATE receiptMaster SET isDeleted = 1 WHERE id = ?`, [id]);
        const invs = await dbQuery(`SELECT iid FROM receiptInvoiceAllocationMaster WHERE rid = ?`, [id]);
        await dbRun(`DELETE FROM receiptInvoiceAllocationMaster WHERE rid = ?`, [id]);
        for (let i of (invs.values || [])) await window.updateInvoicePaidStatus(i.iid);
    }
    window.vibrate('success'); await refreshLocalCache(); window.triggerDriveSync();
    if (type === 'client' && id === currentClientDashboardId) window.showView('dashboardView');
    else window.showView(window.lastMainView);
}

// ==========================================
// 9. VIEW OPENERS & SEARCH
// ==========================================
window.openAddInvoice = function () { invoiceItemsTemp = []; window.renderItems();['inv_id', 'inv_client'].forEach(i => document.getElementById(i).value = ''); document.getElementById('inv_num').value = 'INV-' + Date.now().toString().slice(-4); document.getElementById('inv_date').value = new Date().toISOString().split('T')[0]; document.getElementById('initialReceiptBlock').classList.remove('d-none'); window.showView('invoiceFormView'); }
window.openEditInvoice = async function (id) {
    const invRes = await dbQuery(`SELECT * FROM invoiceMaster WHERE id = ?`, [id]);
    const i = invRes.values[0]; if (!i) return;
    document.getElementById('inv_id').value = id;
    document.getElementById('inv_client').value = loadedData.clients.find(c => c.id === i.clid)?.name || '';
    document.getElementById('inv_date').value = i.date; document.getElementById('inv_due_date').value = i.ddate;
    document.getElementById('inv_num').value = i.inum; document.getElementById('inv_disc').value = i.damt;
    document.getElementById('inv_round').value = i.rof;
    const itemsRes = await dbQuery(`SELECT name, desc, rt, qty, amt FROM invoiceitems WHERE iid = ?`, [id]);
    invoiceItemsTemp = itemsRes.values || []; window.renderItems(); document.getElementById('initialReceiptBlock').classList.add('d-none'); window.showView('invoiceFormView');
}
window.openAddClient = function () { ['c_id', 'c_name', 'c_company', 'c_contact', 'c_email', 'c_mobile', 'c_dob'].forEach(i => document.getElementById(i).value = ''); window.showView('clientFormView'); }
window.openEditClient = function (id) { const c = loadedData.clients.find(x => x.id === id);['c_id', 'c_name', 'c_company', 'c_contact', 'c_email', 'c_mobile', 'c_dob'].forEach(i => document.getElementById(i).value = c[i.replace('c_', '')] || ''); window.showView('clientFormView'); }
window.openAddService = function () { ['s_id', 's_name', 's_desc', 's_rate'].forEach(i => document.getElementById(i).value = ''); window.showView('serviceFormView'); }
window.openEditService = function (id) { const s = loadedData.services.find(x => x.id === id);['s_id', 's_name', 's_desc', 's_rate'].forEach(i => document.getElementById(i).value = s[i.replace('s_', '').replace('rate', 'rt')] || ''); window.showView('serviceFormView'); }
window.openAddReceipt = function () { ['r_id', 'rec_client_input', 'rec_amount', 'rec_notes'].forEach(i => document.getElementById(i).value = ''); document.getElementById('rec_num').value = 'REC-' + Date.now().toString().slice(-4); document.getElementById('rec_date').value = new Date().toISOString().split('T')[0]; window.showView('receiptFormView'); }
window.openQuickSale = function () { document.getElementById('qs_amount').value = ''; document.getElementById('qs_notes').value = ''; new bootstrap.Modal(document.getElementById('quickSaleModal')).show(); }
window.openEditItemModal = function (idx) { const i = invoiceItemsTemp[idx]; document.getElementById('ei_index').value = idx; document.getElementById('ei_name').value = i.name; document.getElementById('ei_desc').value = i.desc; document.getElementById('ei_qty').value = i.qty; document.getElementById('ei_rate').value = i.rt; new bootstrap.Modal(document.getElementById('editItemModal')).show(); }
window.saveEditedItem = function () { const idx = document.getElementById('ei_index').value; const qty = parseFloat(document.getElementById('ei_qty').value); const rt = parseFloat(document.getElementById('ei_rate').value); invoiceItemsTemp[idx].desc = document.getElementById('ei_desc').value; invoiceItemsTemp[idx].qty = qty; invoiceItemsTemp[idx].rt = rt; invoiceItemsTemp[idx].amt = qty * rt; bootstrap.Modal.getInstance(document.getElementById('editItemModal')).hide(); window.renderItems(); }

window.handleClientSearch = function (q) { const r = document.getElementById('invClientResults'); if (!q) return r.classList.add('d-none'); const m = loadedData.clients.filter(c => c.name.toLowerCase().includes(q.toLowerCase())); r.innerHTML = m.map(c => `<button class="list-group-item list-group-item-action" onclick="document.getElementById('inv_client').value='${c.name}'; document.getElementById('invClientResults').classList.add('d-none');">${c.name}</button>`).join(''); r.classList.remove('d-none'); }
window.handleServiceSearch = function (q) { const r = document.getElementById('invServiceResults'); if (!q) return r.classList.add('d-none'); const m = loadedData.services.filter(c => c.name.toLowerCase().includes(q.toLowerCase())); r.innerHTML = m.map(c => `<button class="list-group-item list-group-item-action" onclick="document.getElementById('item_service').value='${c.name}'; document.getElementById('item_rate').value='${c.rt}'; document.getElementById('item_desc').value='${c.desc}'; document.getElementById('invServiceResults').classList.add('d-none');">${c.name} - ₹${c.rt}</button>`).join(''); r.classList.remove('d-none'); }
window.handleReceiptClientSearch = function (q) { const r = document.getElementById('recClientResults'); if (!q) return r.classList.add('d-none'); const m = loadedData.clients.filter(c => c.name.toLowerCase().includes(q.toLowerCase())); r.innerHTML = m.map(c => `<button class="list-group-item list-group-item-action" onclick="document.getElementById('rec_client_input').value='${c.name}'; document.getElementById('rec_client_id').value='${c.id}'; document.getElementById('recClientResults').classList.add('d-none'); filterInvoicesForReceipt('${c.id}');">${c.name}</button>`).join(''); r.classList.remove('d-none'); }
window.filterInvoicesForReceipt = async function (cId) {
    const s = document.getElementById('rec_invoice'); s.innerHTML = '<option value="">Auto-FIFO / Advance</option>';
    const unpaid = await dbQuery(`SELECT id, inum, (namt - COALESCE((SELECT SUM(amt) FROM receiptInvoiceAllocationMaster WHERE iid = invoiceMaster.id), 0)) as balance FROM invoiceMaster WHERE clid = ? AND ispaid = 0 AND isDeleted = 0`, [cId]);
    (unpaid.values || []).filter(i => i.balance > 0).forEach(inv => { s.innerHTML += `<option value="${inv.id}">${inv.inum} (Bal: ${inv.balance.toFixed(2)})</option>`; });
}

window.viewOutstandingClients = function () { document.getElementById('searchClients').value = ':outstanding'; window.switchTab('clients'); window.renderTables(); }
window.viewOverdueInvoices = function () { document.getElementById('searchInvoices').value = ':overdue'; window.switchTab('invoices'); window.renderTables(); }

// ==========================================
// 10. DASHBOARDS & RENDERING
// ==========================================
window.renderTables = async function () {
    await window.renderDashboard();

    let invFilter = document.getElementById('searchInvoices')?.value.toLowerCase() || '';
    let invQuery = `SELECT id, inum, clid, date, namt, ispaid, (namt - COALESCE((SELECT SUM(amt) FROM receiptInvoiceAllocationMaster WHERE iid = invoiceMaster.id), 0)) as balance FROM invoiceMaster WHERE isDeleted = 0`;
    if (invFilter === ':overdue') invQuery += ` AND ispaid = 0 AND ddate < '${new Date().toISOString().split('T')[0]}'`;
    invQuery += ` ORDER BY date DESC LIMIT 50`;
    const invRes = await dbQuery(invQuery);

    document.getElementById('invoiceTableBody').innerHTML = (invRes.values || []).map(i => `
        <div class="list-group-item list-group-item-action" onclick="openInvoicePreview('${i.id}')">
            <div class="d-flex w-100 justify-content-between">
                <h6 class="mb-1">${i.inum} <span class="badge bg-${i.balance <= 0 ? 'success' : 'danger'}">${i.balance <= 0 ? 'Paid' : 'Due'}</span></h6>
                <span>₹${i.namt.toFixed(2)}</span>
            </div>
            <div class="d-flex w-100 justify-content-between align-items-center">
                <small class="text-muted">${loadedData.clients.find(c => c.id === i.clid)?.name || 'Unknown'}</small>
                <small>Bal: ₹${i.balance.toFixed(2)}</small>
                <button class="btn btn-sm btn-link text-success p-0" onclick="event.stopPropagation(); sendWhatsAppReminder('${i.id}')"><i class="bi bi-whatsapp"></i></button>
            </div>
        </div>`).join('') || '<div class="list-group-item text-center text-muted">No invoices found.</div>';

    let clFilter = document.getElementById('searchClients')?.value.toLowerCase() || '';
    let clientsRender = loadedData.clients;
    if (clFilter === ':outstanding') clientsRender = clientsRender.filter(c => c.balanceDue > 0);
    else if (clFilter) clientsRender = clientsRender.filter(c => c.name.toLowerCase().includes(clFilter) || (c.mob && c.mob.includes(clFilter)));
    document.getElementById('clientTableBody').innerHTML = clientsRender.map(c => `
        <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" onclick="openClientDashboard('${c.id}')">
            <div><h6 class="mb-1">${c.name}</h6><small class="text-muted">${c.mob || ''}</small></div>
            <span class="text-${c.balanceDue > 0 ? 'danger' : 'success'} fw-bold">₹${c.balanceDue.toFixed(2)}</span>
        </div>`).join('') || '<div class="list-group-item text-center text-muted">No clients found.</div>';

    let srFilter = document.getElementById('searchServices')?.value.toLowerCase() || '';
    document.getElementById('serviceTableBody').innerHTML = loadedData.services.filter(s => s.name.toLowerCase().includes(srFilter)).map(s => `
        <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" onclick="openEditService('${s.id}')">
            <h6 class="mb-0">${s.name}</h6><span>₹${s.rt.toFixed(2)}</span>
        </div>`).join('') || '<div class="list-group-item text-center text-muted">No services found.</div>';

    const recRes = await dbQuery(`SELECT id, rnum, clid, mode, amt FROM receiptMaster WHERE isDeleted = 0 ORDER BY date DESC LIMIT 50`);
    document.getElementById('receiptTableBody').innerHTML = (recRes.values || []).map(r => `
        <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" onclick="openReceiptPreview('${r.id}')">
            <div><h6 class="mb-1">${r.rnum} <span class="badge bg-secondary">${r.mode}</span></h6><small class="text-muted">${loadedData.clients.find(c => c.id === r.clid)?.name || 'Unknown'}</small></div>
            <span class="text-success fw-bold">+₹${r.amt.toFixed(2)}</span>
        </div>`).join('') || '<div class="list-group-item text-center text-muted">No receipts found.</div>';
}

window.renderDashboard = async function () {
    let tDue = loadedData.clients.reduce((s, c) => s + (c.balanceDue > 0 ? c.balanceDue : 0), 0);
    let today = new Date().toISOString().split('T')[0];
    let yearStr = new Date().getFullYear().toString();

    let [oDueRes, tRevRes, tRecRes] = await Promise.all([
        dbQuery(`SELECT COUNT(*) as cnt FROM invoiceMaster WHERE isDeleted = 0 AND ispaid = 0 AND ddate < ?`, [today]),
        dbQuery(`SELECT SUM(namt) as tot FROM invoiceMaster WHERE isDeleted = 0 AND date LIKE ?`, [yearStr + '%']),
        dbQuery(`SELECT SUM(amt) as tot FROM receiptMaster WHERE isDeleted = 0 AND date LIKE ?`, [yearStr + '%'])
    ]);

    document.getElementById('dashTotalDue').innerText = '₹' + tDue.toFixed(2);
    document.getElementById('dashTotalRev').innerText = '₹' + (tRevRes.values[0]?.tot || 0).toFixed(2);
    document.getElementById('dashTotalRec').innerText = '₹' + (tRecRes.values[0]?.tot || 0).toFixed(2);
    document.getElementById('dashOverdueCount').innerText = oDueRes.values[0]?.cnt || 0;

    document.getElementById('dashTopDebtors').innerHTML = loadedData.clients.filter(c => c.balanceDue > 0).sort((a, b) => b.balanceDue - a.balanceDue).slice(0, 3).map(c => `
        <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" onclick="openClientDashboard('${c.id}')">
            <span>${c.name}</span><span class="text-danger">₹${c.balanceDue.toFixed(2)}</span>
        </div>`).join('');

    const recentInvs = await dbQuery(`SELECT inum as ref, namt as amt, date, 'INV' as type, clid FROM invoiceMaster WHERE isDeleted = 0 ORDER BY date DESC LIMIT 5`);
    const recentRecs = await dbQuery(`SELECT rnum as ref, amt, date, 'REC' as type, clid FROM receiptMaster WHERE isDeleted = 0 ORDER BY date DESC LIMIT 5`);
    let activity = [...(recentInvs.values || []), ...(recentRecs.values || [])].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 10);

    document.getElementById('dashRecentActivity').innerHTML = activity.map(a => {
        const cName = loadedData.clients.find(c => c.id === a.clid)?.name || 'Unknown';
        const icon = a.type === 'INV' ? '<i class="bi bi-file-text text-primary"></i>' : '<i class="bi bi-cash text-success"></i>';
        const text = a.type === 'INV' ? `Created <b>${a.ref}</b> for ${cName} (₹${a.amt})` : `Received <b>₹${a.amt}</b> from ${cName}`;
        return `<div class="list-group-item d-flex justify-content-between align-items-center"><div class="d-flex align-items-center"><div class="fs-4 me-3">${icon}</div><div><small>${text}</small></div></div><small class="text-muted">${a.date}</small></div>`;
    }).join('') || '<div class="list-group-item text-muted">No recent activity.</div>';
}

window.openClientDashboard = function (cId) {
    currentClientDashboardId = cId; const c = loadedData.clients.find(x => x.id === cId); if (!c) return;
    document.getElementById('cd_editBtn').onclick = () => window.openEditClient(cId);
    document.getElementById('cd_recordReceiptBtn').onclick = () => { window.openAddReceipt(); document.getElementById('rec_client_input').value = c.name; window.handleReceiptClientSearch(c.name); };
    document.getElementById('cd_statementBtn').onclick = () => window.openStatement(cId);
    window.setCdFilter('6m'); window.showView('clientDashboardView');
}

window.setCdFilter = async function (val) {
    const c = loadedData.clients.find(x => x.id === currentClientDashboardId);
    document.getElementById('cd_clientDetails').innerHTML = `<h3 class="mb-1">${c.name}</h3><p class="text-muted mb-2">${c.mob || ''}</p><h4 class="${c.balanceDue > 0 ? 'text-danger' : 'text-success'}">Bal: ₹${c.balanceDue.toFixed(2)}</h4>`;

    let dateFilter = ''; let params = [c.id]; let now = new Date();
    if (val === '3m') { now.setMonth(now.getMonth() - 3); dateFilter = 'AND date >= ?'; params.push(now.toISOString().split('T')[0]); }
    else if (val === '6m') { now.setMonth(now.getMonth() - 6); dateFilter = 'AND date >= ?'; params.push(now.toISOString().split('T')[0]); }
    else if (val === 'ty') { dateFilter = 'AND date LIKE ?'; params.push(now.getFullYear().toString() + '%'); }

    const invRes = await dbQuery(`SELECT date as d, inum as ref, 'INV' as typ, namt as amt FROM invoiceMaster WHERE clid = ? AND isDeleted = 0 ${dateFilter}`, params);
    const recRes = await dbQuery(`SELECT date as d, rnum as ref, 'REC' as typ, amt FROM receiptMaster WHERE clid = ? AND isDeleted = 0 ${dateFilter}`, params);

    let items = [...(invRes.values || []), ...(recRes.values || [])].sort((a, b) => new Date(b.d) - new Date(a.d));
    document.getElementById('cd_ledgerList').innerHTML = items.map(i => `
        <div class="list-group-item d-flex justify-content-between align-items-center">
            <div><h6 class="mb-1"><span class="badge bg-${i.typ === 'INV' ? 'primary' : 'success'}">${i.typ}</span> ${i.ref}</h6><small class="text-muted">${i.d}</small></div>
            <span class="fw-bold text-${i.typ === 'INV' ? 'dark' : 'success'}">${i.typ === 'INV' ? '' : '+'}${i.amt.toFixed(2)}</span>
        </div>`).join('');
}

// ==========================================
// 11. PREVIEW / PDF / SHARE
// ==========================================
window.openInvoicePreview = async function (id) {
    const invRes = await dbQuery(`SELECT * FROM invoiceMaster WHERE id = ?`, [id]);
    const inv = invRes.values[0]; if (!inv) return;
    const cli = loadedData.clients.find(c => c.id === inv.clid);

    const allocs = await dbQuery(`SELECT SUM(amt) as paid FROM receiptInvoiceAllocationMaster WHERE iid = ?`, [id]);
    const bal = inv.namt - (allocs.values[0]?.paid || 0);

    const itemsRes = await dbQuery(`SELECT * FROM invoiceitems WHERE iid = ?`, [id]);
    let itemsHtml = (itemsRes.values || []).map(i => `<tr><td><b>${i.name}</b><br><small>${i.desc}</small></td><td>${i.rt}</td><td>${i.qty}</td><td class="text-end">${i.amt.toFixed(2)}</td></tr>`).join('');

    let logoHtml = loadedData.company.logo ? `<img src="${loadedData.company.logo}" style="max-height:60px; object-fit:contain;"><br>` : '';
    let upiHtml = loadedData.company.upi ? `<br><br><b>UPI:</b> ${loadedData.company.upi}<br><b>Name:</b> ${loadedData.company.upiName || ''}` : '';

    let html = `<div style="display:flex; justify-content:space-between; border-bottom:2px solid #000; padding-bottom:10px;"><div>${logoHtml}<h2>${loadedData.company.name || 'Company'}</h2><small>${loadedData.company.add_txt || ''}</small></div><div class="text-end"><h1 style="color:#0d6efd;">INVOICE</h1><b># ${inv.inum}</b><br>Date: ${inv.date}</div></div><div style="margin-top:20px;"><b>BILLED TO:</b><br>${cli.name}<br>${cli.mob || ''}</div><table style="margin-top:20px;width:100%;border-collapse:collapse;"><thead><tr><th>Item</th><th>Rate</th><th>Qty</th><th class="text-end">Amount</th></tr></thead><tbody>${itemsHtml}</tbody></table><div style="display:flex; justify-content:space-between; margin-top:20px;"><div>${upiHtml}</div><div class="text-end"><b>Subtotal: </b>₹${inv.gamt.toFixed(2)}<br><b>Net Total: </b>₹${inv.namt.toFixed(2)}<br><b>Balance Due: </b>₹${bal.toFixed(2)}</div></div>`;
    setupPreview(html, { id: inv.id, type: 'Invoice' }, () => window.openEditInvoice(id), () => window.confirmDelete('invoice', id));
}

window.openReceiptPreview = async function (id) {
    const recRes = await dbQuery(`SELECT * FROM receiptMaster WHERE id = ?`, [id]);
    const r = recRes.values[0]; if (!r) return;
    const cli = loadedData.clients.find(c => c.id === r.clid);
    let logoHtml = loadedData.company.logo ? `<img src="${loadedData.company.logo}" style="max-height:60px; object-fit:contain;"><br>` : '';
    let html = `<div style="display:flex; justify-content:space-between; border-bottom:2px solid #000; padding-bottom:10px;"><div>${logoHtml}<h2>${loadedData.company.name || 'Company'}</h2><small>${loadedData.company.add_txt || ''}</small></div><div class="text-end"><h1 style="color:#198754;">RECEIPT</h1><b># ${r.rnum}</b><br>Date: ${r.date}</div></div><div style="text-align:center; margin: 40px 0; padding:20px; background:#f8f9fa;"><h3>AMOUNT RECEIVED</h3><h1 style="color:#198754;">₹${r.amt.toFixed(2)}</h1></div><table style="width:100%;"><tr><td><b>From:</b></td><td>${cli.name}</td></tr><tr><td><b>Mode:</b></td><td>${r.mode}</td></tr></table>`;
    setupPreview(html, { id: r.id, type: 'Receipt' }, null, () => window.confirmDelete('receipt', id));
}

window.openStatement = async function (cId) {
    const cli = loadedData.clients.find(c => c.id === cId);
    const invRes = await dbQuery(`SELECT date as d, inum as ref, 'INV' as typ, namt as amt FROM invoiceMaster WHERE clid = ? AND isDeleted = 0`, [cId]);
    const recRes = await dbQuery(`SELECT date as d, rnum as ref, 'REC' as typ, amt FROM receiptMaster WHERE clid = ? AND isDeleted = 0`, [cId]);

    let items = [...(invRes.values || []), ...(recRes.values || [])];
    items.forEach(i => { if (i.typ === 'REC') i.amt = -i.amt; i.dateObj = new Date(i.d); });
    items.sort((a, b) => a.dateObj - b.dateObj);

    let rows = '', run = 0; items.forEach(i => { run += i.amt; rows += `<tr><td>${i.d}</td><td>${i.typ}</td><td>${i.ref}</td><td class="text-end">${Math.abs(i.amt).toFixed(2)}</td><td class="text-end"><b>${run.toFixed(2)}</b></td></tr>`; });
    let logoHtml = loadedData.company.logo ? `<img src="${loadedData.company.logo}" style="max-height:60px; object-fit:contain;"><br>` : '';
    let html = `<div style="display:flex; justify-content:space-between; border-bottom:2px solid #000; padding-bottom:10px;"><div>${logoHtml}<h2>${loadedData.company.name || 'Company'}</h2></div><div class="text-end"><h1 style="color:#0d6efd;">STATEMENT</h1><b>${cli.name}</b></div></div><table style="margin-top:20px;width:100%;border-collapse:collapse;"><thead><tr><th style="text-align:left">Date</th><th style="text-align:left">Type</th><th style="text-align:left">Ref</th><th class="text-end">Amt</th><th class="text-end">Bal</th></tr></thead><tbody>${rows}</tbody></table><h3 class="text-end" style="margin-top:20px;">Final Balance: ₹${run.toFixed(2)}</h3>`;
    setupPreview(html, { id: cli.id, type: 'Statement' }, null, null);
}

function setupPreview(html, ctx, onEdit, onDel) {
    currentPreviewContext = ctx; document.getElementById('previewContent').innerHTML = html;
    document.getElementById('prevBtnEdit').style.display = onEdit ? 'block' : 'none'; if (onEdit) document.getElementById('prevBtnEdit').onclick = onEdit;
    document.getElementById('prevBtnDelete').style.display = onDel ? 'block' : 'none'; if (onDel) document.getElementById('prevBtnDelete').onclick = onDel;
    window.showView('previewView'); window.zoomPreview(0);
}

window.zoomPreview = function (delta) {
    currentZoom += delta; if (currentZoom < 0.3) currentZoom = 0.3; if (currentZoom > 2) currentZoom = 2;
    const w = document.getElementById('previewScaleWrapper'); const c = document.getElementById('previewContent');
    w.style.transform = `scale(${currentZoom})`; w.style.width = (c.offsetWidth * currentZoom) + 'px'; w.style.height = (c.offsetHeight * currentZoom) + 'px';
}

window.sharePDF = async function () {
    const btn = document.getElementById('prevBtnShare'); btn.disabled = true;
    try {
        const pdf = await html2pdf().set({ margin: 0, filename: `${currentPreviewContext.type}_${currentPreviewContext.id}.pdf`, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2 }, jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' } }).from(document.getElementById('previewContent')).output('blob');
        const file = new File([pdf], `${currentPreviewContext.type}.pdf`, { type: 'application/pdf' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) await navigator.share({ title: 'Document', files: [file] }); else { const a = document.createElement('a'); a.href = URL.createObjectURL(pdf); a.download = file.name; a.click(); }
    } catch (e) { alert('Failed to share PDF'); } finally { btn.disabled = false; }
}

window.printHTML = function (content) {
    const f = document.createElement('iframe'); f.style.display = 'none'; document.body.appendChild(f);
    f.contentWindow.document.write(`<html><head><style>@page{size:A4 portrait; margin:10mm;} body{font-family:sans-serif;} table{width:100%; border-collapse:collapse;} th,td{border:1px solid #000; padding:8px;} .text-end{text-align:right;}</style></head><body>${content}<script>window.onload=()=>window.print();<\/script></body></html>`); f.contentWindow.document.close();
}

window.importContact = async function () {
    try {
        if (window.Capacitor?.Plugins?.Contacts) {
            const { Contacts } = window.Capacitor.Plugins; await Contacts.requestPermissions();
            const res = await Contacts.pickContact({ projection: { name: true, phones: true, emails: true } });
            if (res?.contact) {
                if (res.contact.name?.display) { document.getElementById('c_name').value = res.contact.name.display; document.getElementById('c_contact').value = res.contact.name.display; }
                if (res.contact.phones?.length > 0) document.getElementById('c_mobile').value = res.contact.phones[0].number.replace(/[^\d]/g, '');
                if (res.contact.emails?.length > 0) document.getElementById('c_email').value = res.contact.emails[0].address;
            }
        } else if ('contacts' in navigator) {
            const res = await navigator.contacts.select(['name', 'email', 'tel'], { multiple: false });
            if (res.length > 0) {
                if (res[0].name?.length > 0) { document.getElementById('c_name').value = res[0].name[0]; document.getElementById('c_contact').value = res[0].name[0]; }
                if (res[0].tel?.length > 0) document.getElementById('c_mobile').value = res[0].tel[0].replace(/[^\d]/g, '');
                if (res[0].email?.length > 0) document.getElementById('c_email').value = res[0].email[0];
            }
        } else alert("Contact import not supported on this device.");
    } catch (e) { }
}

// Global Click Listener for Dropdowns
document.addEventListener('click', function (e) {
    const hideIfOutside = (inputId, resId) => {
        if (!e.target.closest(`#${inputId}`) && !e.target.closest(`#${resId}`)) {
            const el = document.getElementById(resId);
            if (el) el.classList.add('d-none');
        }
    };
    hideIfOutside('inv_client', 'invClientResults');
    hideIfOutside('item_service', 'invServiceResults');
    hideIfOutside('rec_client_input', 'recClientResults');
});